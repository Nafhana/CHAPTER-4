package fibonacci;
import java.util.Scanner;
public class Fibonacci {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
                
        // Prompt user for input
        System.out.print("Enter the number of Fibonacci values to display: ");
        int numberOfValues = input.nextInt();

        // Display the Fibonacci series
        System.out.println("Fibonacci series with " + numberOfValues + " values:");
        printFibonacciSeries(numberOfValues);

        input.close();
    }

    public static void printFibonacciSeries(int numberOfValues) {

        int a = 0, b = 1;

        // Print the first value
        if (numberOfValues >= 1) {
            System.out.print(a + " ");
        }

        // Print the second value
        if (numberOfValues >= 2) {
            System.out.print(b + " ");
        }

        // Print the rest of the series
        for (int i = 3; i <= numberOfValues; i++) {
            int next = a + b;
            System.out.print(next + " ");
            a = b;
            b = next;
        }

        System.out.println(); // For a new line
    }
}