package listtest;
import java.util.Scanner;
public class ListTest {
    public static void main(String[] args) {
        
        
        Scanner input = new Scanner(System.in);
        // Input the total number of students
        System.out.print("How many students are in your class: ");
        float student = input.nextFloat();

        int pass = 0;

        // Loop to collect each student's test mark
        for (int i = 1; i <= student; i++) {
            System.out.print("Enter the mark for student " + i + ": ");
            int mark = input.nextInt();

            // Check how many student passed
            if (mark >= 65) {
                pass++;
            }
        }

        // Calculate the percentage
        float percentage = ( pass / student) * 100;

        // Determine the result based on the pass percentage
        if (percentage >= 50) {
            System.out.printf("\n%.2f%% students passed. Bonus to instructor!\n", percentage);
        } else {
            float fail = 100 - percentage;
            System.out.printf("\n%.2f%% students failed.\n", fail);
        }

        input.close();
    }
    
}
