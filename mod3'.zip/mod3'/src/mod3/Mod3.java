package mod3;
import java.util.Scanner;

public class Mod3 {
    public static void main(String[] args) {
        
        char conv;
        float mass, dis, temp, num;
        String choice;
        
        Scanner input = new Scanner(System.in);
        
        do {
            // Display menu
            System.out.println("-Converter Available-\n");
            System.out.println("a. Mass converter (g - kg)");
            System.out.println("b. Distance converter (m - km)");
            System.out.println("c. Temperature converter (Celsius - Fahrenheit)");
            
            // User choose which converter
            System.out.println("\nChoose the converter (a-c): ");
            conv = input.next().charAt(0);
            
            // Enter number to convert
            System.out.println("Insert number to convert: ");
            num = input.nextFloat();
            
            // Calculation by selection
            switch (conv) {
                case 'a':
                    mass = num / 1000;
                    System.out.println("\n" + num + "g = " + mass + "kg");
                    break;
                case 'b':
                    dis = num / 1000;
                    System.out.println("\n" + num + "m = " + dis + "km");
                    break;
                case 'c':
                    temp = (num * 9/5) + 32;
                    System.out.println("\n" + num + "C = " + temp + "F");
                    break;
                default:
                    System.out.println("\nInvalid option.");
                    break;
            }
            
            // Ask the user if they want to exit
            System.out.print("Do you want to exit? (yes/no): ");
            input.nextLine();  // Consume the leftover newline
            choice = input.nextLine();
            System.out.print("\n");
            
        } while (!choice.equalsIgnoreCase("yes"));
        
        input.close();
    }
}
