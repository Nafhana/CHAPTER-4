package mod2;
import java.util.Scanner;

public class Mod2 {
    public static void main(String[] args) {
        
        int quantity, smoothie;
        float price = 0, totalPrice, discount = 0;
        char member;
        String choice = ""; // Initialize choice with an empty string
        Scanner input = new Scanner(System.in);
        
        do {
            // Display menu
            System.out.println("MENU");
            System.out.println("1. Strawberry Smoothie : RM10");
            System.out.println("2. Blueberry Smoothie : RM10");
            System.out.println("3. Banana Smoothie : RM8");
            System.out.println("4. Mango Smoothie : RM8");
            
            // User enters orders information
            System.out.print("What would you like to order (1-4): ");
            smoothie = input.nextInt();
            System.out.print("Enter the smoothie quantity: ");
            quantity = input.nextInt();
            input.nextLine(); // Clear the buffer
            
            // Set price for smoothie
            switch (smoothie) {
                case 1:
                case 2:
                    price = 10;
                    break;
                case 3:
                case 4:
                    price = 8;
                    break;
                default:
                    System.out.println("Invalid number");
                    continue; // Skip to the next iteration of the loop
            }
            
            // Calculate total price
            totalPrice = price * quantity;
            
            // Ask for membership
            System.out.print("Do you have membership? (y/n): ");
            member = input.nextLine().charAt(0);
            
            // Membership discount
            if (Character.toLowerCase(member) == 'y') {
                discount = totalPrice * 0.20f;
                totalPrice -= discount;
            }
            
            // Display the order information
            System.out.printf("\nYour order: %d\n", smoothie);
            System.out.printf("Price per smoothie: RM%.2f\n", price);
            System.out.printf("Quantity: %d\n", quantity);
            System.out.printf("Total price before discount: RM%.2f\n", price * quantity);
            if (discount > 0) {
                System.out.printf("Membership discount: RM%.2f\n", discount);
                System.out.printf("Price after discount: RM%.2f\n", totalPrice);
            } else {
                System.out.printf("Total price: RM%.2f\n", totalPrice);
            }
            
            // Ask the user if they want to exit
            System.out.print("\nDo you want to exit? (yes/no): ");
            choice = input.nextLine();
            
        } while (!choice.equalsIgnoreCase("yes"));
        
        System.out.println("Thank you for using the system. Goodbye!");
        input.close();
    }
}
