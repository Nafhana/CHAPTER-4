package salecommision;

import java.util.Scanner;

public class SaleCommision {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        String choice;

        do {
            // Show items available
            System.out.println("ITEM AVAILABLE\n 1. Tiramisu cake\n "
                    + "2. Red Velvet Cake\n 3. Chocolate Mouse Cake\n 4. Indulgence Cake\n");

            // Input how many of each item sold
            System.out.print("Tiramisu Sold: ");
            int tiramisu = input.nextInt();
            System.out.print("Red Velvet Sold: ");
            int redvelvet = input.nextInt();
            System.out.print("Chocolate Mouse Sold: ");
            int choc = input.nextInt();
            System.out.print("Indulgence Sold: ");
            int indulgence = input.nextInt();

            float sale, earning, x, comm = 5;

            // Calculate gross sale
            sale = (tiramisu * 15) + (redvelvet * 20) + (choc * 18) + (indulgence * 27);
            earning = (comm / 100) * sale;
            x = 600 + earning;
            System.out.println("You receive RM" + x);

            // Ask the user if they want to exit
            System.out.print("Do you want to exit? (yes/no): ");
            choice = input.next();
            System.out.print("\n");
        } while (!choice.equalsIgnoreCase("yes"));
    }
}

