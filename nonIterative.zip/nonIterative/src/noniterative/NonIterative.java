package noniterative;
public class NonIterative {
    public static void main(String[] args) {
        
        // Set the value of n here
        int n = 5;

        // Calculate the factorial
        long factorial = calcFactorial(n);

        // Display the result
        String factorialEx = generateFactorial(n);
        System.out.println(factorialEx + " = " + factorial);
    }

    public static long calcFactorial(int n) {
        long result = 1;

        // Calculate factorial iteratively
        for (int i = 1; i <= n; i++) {
            result *= i;
        }

        return result;
    }

    public static String generateFactorial(int n) {
        if (n <= 0) {
            return "Invalid input";
        }
        
        //StringBuilder allow moify string value
        StringBuilder expression = new StringBuilder();

        for (int i = n; i > 1; i--) {
            expression.append(i).append(" * ");
        }
        expression.append("1");

        return n + "! = " + expression.toString();
    }
}