package password;
import java.util.Scanner;
public class Password {
    public static void main(String[] args) {
        
        // Define the correct password
        final String CORRECT_PASSWORD = "passpass";
        // Set the maximum number of attempts
        final int Maxattempt = 3;
        
        Scanner input = new Scanner(System.in);
        int attempts = 0;
        boolean accessGranted = false;

        // Loop to allow the user to enter the password
        while (attempts < Maxattempt) {
            System.out.print("Enter your password: ");
            String password = input.nextLine();
            
            // Check if the entered password is correct
            if (password.equals(CORRECT_PASSWORD)) {
                accessGranted = true;
                break;
            } else {
                attempts++;
                System.out.println("Incorrect password.\n");
            }
        }
        
        // Display the result
        if (accessGranted) {
            System.out.println("Access granted.");
        } else {
            System.out.println("You have used all attempts. Please try again later");
        }

        input.close();

    }
    
}
