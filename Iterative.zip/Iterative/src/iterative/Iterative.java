package iterative;
import java.util.Scanner;
public class Iterative {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);

        // Prompt user for input
        System.out.print("Enter a integer to calculate factorial: ");
        int n = input.nextInt();

        // Calculate the factorial
        long factorial = calcFactorial(n);

        // Display the result
        String factorialExpression = generateFactorial(n);
        System.out.println(factorialExpression + " = " + factorial);

        input.close();
    }

    public static long calcFactorial(int n) {
        long result = 1;

        // Calculate factorial iteratively
        for (int i = 1; i <= n; i++) {
            result *= i;
        }

        return result;
    }

    public static String generateFactorial(int n) {

        StringBuilder expression = new StringBuilder();

        for (int i = n; i > 1; i--) {
            expression.append(i).append(" * ");
        }
        expression.append("1");

        return n + "! = " + expression.toString();
    }
}