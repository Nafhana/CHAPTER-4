package intsequence;
import java.util.Scanner;
public class IntSequence {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        String choice;
    
        do {
            // Input the total number of numbers in the sequence
            System.out.print("How many numbers are in your sequence: ");
            int seq = input.nextInt();
            
            int even = 0, odd = 0;

            // Loop to collect each value
            for (int i = 1; i <= seq; i++) {
                System.out.print("Enter the value of the " + i + " number: ");
                int value = input.nextInt();
                
                // Count odd and even numbers
                if (value % 2 == 0) {
                    even++;
                } else {
                    odd++;
                }
            }

            // Display the count of odd and even numbers
            System.out.println("\nEven numbers: " + even);
            System.out.println("Odd numbers: " + odd);

            // Ask the user if they want to exit
            System.out.print("Do you want to exit? (yes/no): ");
            choice = input.next();
            System.out.print("\n");
        } while (!choice.equalsIgnoreCase("yes"));
    }
}
