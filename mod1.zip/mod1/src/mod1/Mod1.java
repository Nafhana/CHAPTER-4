package mod1;

import java.util.Scanner;

public class Mod1 {
    public static void main(String[] args) {
        
        String itemName, colour, choice;
        int quantity;
        float price, discountRate = 0, totalPrice, after, discount;
        Scanner input = new Scanner(System.in);
        
        do {
            // User enter item's information
            System.out.println("Enter the name of the item :");
            itemName = input.nextLine();
            
            System.out.println("Discount by colours:");
            System.out.println("1. Red : 45%");
            System.out.println("2. Green : 35%");
            System.out.println("3. Blue : 40%");
            System.out.println("4. Yellow : 15%");
            
            System.out.println("Enter the color of the item (Red/Green/Blue/Yellow):");
            colour = input.nextLine().toLowerCase();
            
            System.out.println("Enter the price :");
            price = input.nextFloat();
            
            System.out.println("Enter the item quantity :");
            quantity = input.nextInt();
            
            // Clear the buffer
            input.nextLine();
            
            // Set the discount rate based on the color
            switch (colour) {
                case "red":
                    discountRate = 45;
                    break;
                case "green":
                    discountRate = 35;
                    break;
                case "blue":
                    discountRate = 40;
                    break;
                case "yellow":
                    discountRate = 15;
                    break;
                default:
                    System.out.println("Invalid color entered. No discount will be applied.");
                    discountRate = 0; // Ensure no discount if the color is invalid
                    break;
            }
            
            // Calculate total price and the price after discount
            totalPrice = price * quantity;
            discount = (discountRate / 100) * totalPrice;
            after = totalPrice - discount;
            
            // Show all item's information
            System.out.println("Item name: " + itemName);
            System.out.println("Item price: " + price);
            System.out.println("Item quantity: " + quantity);
            System.out.println("Total Price: " + totalPrice);
            System.out.printf("Discount rate: %.2f%%\n", discountRate);
            System.out.printf("Item price after discount: %.2f\n", after);
            
            // Ask the user if they want to exit
            System.out.print("Do you want to exit? (yes/no): ");
            choice = input.nextLine();
            System.out.print("\n");
        } while (!choice.equalsIgnoreCase("yes"));
        
        input.close();
    }
}

